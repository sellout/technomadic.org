package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Body
	extends BlockContainer
	implements StxtElement
{
    /**
     * @see com.valentsolutions.stxt.dom.BlockContainer#getElementName()
     */
    protected String getElementName()
    {
        return "body";
    }

}
