package com.valentsolutions.stxt.dom;

/**
 * This interface is used to identify any "inline" elements (bold, italic,
 * link, etc.)
 */
public interface InlineElement
    extends StxtElement
{
}
