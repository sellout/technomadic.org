package com.valentsolutions.stxt.dom;

/**
 * 
 */
public abstract class BlockMarkup
	extends InlineContainer
	implements Block
{
}
