package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Item
	extends BlockContainer
	implements StxtElement
{
    /**
     * @see com.valentsolutions.stxt.dom.BlockContainer#getElementName()
     */
    protected String getElementName()
    {
        return "item";
    }
}
