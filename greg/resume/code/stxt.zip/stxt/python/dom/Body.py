class Body (BlockContainer, StxtElement)

    def get_element_name():
        return "body"