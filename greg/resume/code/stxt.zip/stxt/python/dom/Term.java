package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Term
	extends InlineContainer
    implements StxtElement
{
    /**
     * @see com.valentsolutions.stxt.dom.InlineContainer#getElementName()
     */
    protected String getElementName()
    {
        return "term";
    }
}
