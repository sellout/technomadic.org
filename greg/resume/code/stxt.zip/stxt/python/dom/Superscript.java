package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Superscript
	extends InlineMarkup
{
    /**
     * @see com.valentsolutions.stxt.dom.InlineContainer#getElementName()
     */
    protected String getElementName()
    {
        return "superscript";
    }
}
