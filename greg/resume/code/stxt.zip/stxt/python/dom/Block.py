# This interface is used to identify any "block" elements (para, blockquote, 
# lists, etc)

class Block (StxtElement):
    "This interface is used to identify any "block" elements (para, blockquote, lists, etc)."