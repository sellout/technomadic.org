package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Subscript
	extends InlineMarkup
{
    /**
     * @see com.valentsolutions.stxt.dom.InlineContainer#getElementName()
     */
    protected String getElementName()
    {
        return "subscript";
    }
}
