package com.valentsolutions.stxt.dom;

/**
 * 
 */
public class Definition
	extends InlineContainer
    implements StxtElement
{
    /**
     * @see com.valentsolutions.stxt.dom.InlineContainer#getElementName()
     */
    protected String getElementName()
    {
        return "definition";
    }
}
