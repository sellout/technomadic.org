package com.valentsolutions.stxt.dom;

/**
 * 
 */
public abstract class InlineMarkup
	extends InlineContainer
	implements InlineElement
{
}
