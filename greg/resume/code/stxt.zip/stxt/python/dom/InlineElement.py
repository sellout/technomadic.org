class InlineElement (StxtElement):
    "This interface is used to identify any "inline" elements (bold, italic, link, etc.)"
