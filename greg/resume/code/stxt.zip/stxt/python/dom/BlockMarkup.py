class BlockMarkup (InlineContainer, Block):
