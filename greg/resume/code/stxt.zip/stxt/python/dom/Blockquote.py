class Blockquote (BlockContainer, Block):

    def get_element_name():
        return "blockquote"